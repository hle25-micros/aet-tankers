<?php
$site_url = get_option( 'siteurl' );
?>
<style type="text/css">
<!--
.style2 {color: #999999}
.style3 {color: #666666}
.style4 {
	color: #D50948;
	font-weight: bold;
	font-style: italic;
}
.style5 {color: #D50948}
.style6 {
	border: 2px solid;
	padding:10px;
	text-align: center;
	color: #D50948;
	font-size: 12px;
	font-style: italic;
}
-->
</style>
<hr />  

    <h2>USE</h2>
   
   <p> Click <span class="style5"><strong>edit</strong></span> to set the slider.
Add, edit, or delete the items you want to display the slider. You can see here the options you have for item:</p>
<ul>
<li><img src="<?php echo plugins_url('', __FILE__); ?>/icono1.png" width="50" height="50" /> <span class="style5"><em><strong>Main Image</strong></em>.</span> <span class="style3">Choose the main image. </span></li>
<li><img src="<?php echo plugins_url('', __FILE__); ?>/icono3.png" width="50" height="50" /> <span class="style5"><strong><em>Title</em></strong>. </span><span class="style3">The title of each image. </span></li>
<li><img src="<?php echo plugins_url('', __FILE__); ?>/icono5.png" width="50" height="50" /> <span class="style4">Link.</span> <span class="style3">You can add a link in the image. </span></li>
</ul>
<BR/>
<p><strong>You can en
ter the url of the images manually or press the button "change image". Pressing the button will load the library wordpress images, select the image you want and click "Insert in Post" to insert the image in the slider.</strong>
</p>
<p>After the items, the slider has the configuration options and overall design of the slider. Width, height and time transition.</p>
<hr />
<p class="style6">
<h3><a href="http://www.extendyourweb.com/wordpress-theme/">View and Download Wordpress Extend Theme with best slider plugin.</a></h3>
Theme optimized for search engines and with only two css files and js reduced in size for faster loading. We have included easy to use and elegant shortcodes. It includes an exclusive “theme options” with multiple options for pages and posts.
<h3><a href="http://extendyourweb.com/wordpress-theme/plugins/extendyourweb-plugins/horizontal-slider/">Horizontal slider manual and samples</a></h3>
</p>

<hr>

</div>